---
name: owl-dns-synergy
description: Unified dual-channel resilient access engine. Fetch URLs via HTTP proxy or DNS tunnel, output as Obsidian Markdown.
version: 1.0.0
author: Z.ai Research Division
---

# OWL-DNS-Synergy Skill

Fetch any URL through an intelligent dual-channel router that automatically selects the optimal access method: HTTP proxy evasion (for anti-bot sites) or DNS tunneling (for captive portals/restricted networks). All outputs are Obsidian-compatible Markdown.

## Commands

### `fetch`
Fetch a URL and return the content as Obsidian Markdown.

```bash
owl-dns-synergy fetch <url> [--channel auto|http|dns] [--verbose]
```

The router tries HTTP first (via proxy pool with Chrome TLS fingerprinting). If blocked, it falls back to DNS tunneling. Output is converted to Obsidian Flavored Markdown with wikilinks, callouts, and frontmatter properties.

### `chat`
Send a message to an LLM via DNS tunnel.

```bash
owl-dns-synergy chat <message> [--server host] [--port port]
```

### `stats`
View current channel statistics including quality scores, preferences, and circuit breaker states.

```bash
owl-dns-synergy stats
```

### `generate-key`
Generate a Fernet encryption key for DNS tunneling.

```bash
owl-dns-synergy generate-key
```

## Integration with Obsidian

- All fetched content is output as Obsidian Markdown with frontmatter (source, channel, timestamp, quality_score)
- Channel statistics can be rendered as Obsidian Bases (.base files)
- Network topology can be rendered as JSON Canvas (.canvas files)
- Use `obsidian-cli` skill to automate vault operations

## Dependencies

- Python 3.10+
- httpx, aiohttp, circuitbreaker, cryptography, dnslib, openai, prometheus-client
- Optional: redis, curl_cffi for enhanced functionality
