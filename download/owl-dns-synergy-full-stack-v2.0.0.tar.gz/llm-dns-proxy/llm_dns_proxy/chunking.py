"""
DNS message chunking and reassembly utilities.
Handles the splitting of encrypted messages into DNS-compatible chunks.
"""

import base64
import math
import time
import uuid
import zlib
from typing import List, Dict, Optional, Tuple

from .config import get_dns_suffix, get_dns_suffix_parts, format_dns_query, validate_dns_suffix_in_query


def base36encode(number: int) -> str:
    """Convert integer to base36 string using 0-9a-z"""
    if number == 0:
        return '0'

    alphabet = '0123456789abcdefghijklmnopqrstuvwxyz'
    result = ''
    while number:
        number, remainder = divmod(number, 36)
        result = alphabet[remainder] + result
    return result


def base36decode(string: str) -> int:
    """Convert base36 string to integer"""
    return int(string, 36)


def bytes_to_base36(data: bytes) -> str:
    """Convert bytes to base36 string with length prefix"""
    # Convert bytes to big integer
    number = int.from_bytes(data, byteorder='big')
    encoded = base36encode(number)
    # Prefix with original length to preserve it during decode
    length_prefix = base36encode(len(data))
    # Use '_' as separator instead of 'z' — 'z' is a valid base36 digit (35)
    # causing collision when len(data) encodes to a string containing 'z'
    return f"{length_prefix}_{encoded}"


def base36_to_bytes(string: str) -> bytes:
    """Convert base36 string back to bytes"""
    # Split at '_' separator (non-base36 char, avoids collision with 'z' digit)
    parts = string.split('_', 1)
    if len(parts) != 2:
        raise ValueError("Invalid base36 format")

    length_str, data_str = parts
    original_length = base36decode(length_str)
    number = base36decode(data_str)

    # Convert back to bytes with original length
    if number == 0:
        return b'\x00' * original_length

    byte_length = (number.bit_length() + 7) // 8
    result = number.to_bytes(byte_length, byteorder='big')

    # Pad with leading zeros if needed
    if len(result) < original_length:
        result = b'\x00' * (original_length - len(result)) + result

    return result


class DNSChunker:
    MAX_DNS_LABEL_LENGTH = 63
    MAX_DNS_RECORD_LENGTH = 255
    MAX_DNS_QNAME_LENGTH = 253
    MAX_DATA_LABEL_LENGTH = 50  # Conservative limit for single label

    def __init__(self, max_pending_sessions: int = 10000, session_ttl: float = 60.0):
        self.pending_messages: Dict[str, Dict[int, str]] = {}
        self.total_chunks: Dict[str, int] = {}
        # Memory Fix M-D1/M-D3: TTL-based session eviction + max session cap
        self._session_time: Dict[str, float] = {}
        self._max_pending_sessions = max_pending_sessions
        self._session_ttl = session_ttl

    def _split_data_into_labels(self, data: str, max_per_label: int) -> List[str]:
        """Split long data into multiple DNS labels"""
        labels = []
        for i in range(0, len(data), max_per_label):
            labels.append(data[i:i + max_per_label])
        return labels

    def create_chunks(self, encrypted_data: bytes, session_id: str = None) -> List[str]:
        """
        Split encrypted data into DNS-compatible chunks with proper qname length validation.
        Returns list of DNS query strings in format: m.sessionid.index.total.data1.data2.<suffix>
        """
        if session_id is None:
            # Use 8-hex-digit session ID (4 billion values, avoids birthday collision)
            # Previously 3-digit (1000 values) caused >50% collision at 38+ sessions
            session_id = uuid.uuid4().hex[:8]

        # Convert Fernet token to DNS-safe base36 for labels
        # Base36 uses only 0-9a-z which is DNS-safe and more efficient than base32
        data_b36 = bytes_to_base36(encrypted_data)

        # Calculate base qname overhead: "m." + sessionid + "." + index + "." + total + "." + ".<suffix>"
        # Worst case with _sonos._tcp.local: m.999.999.999.._sonos._tcp.local = ~39 chars + dots
        dns_suffix = get_dns_suffix()
        base_overhead = len(f"m.999.999.999.{dns_suffix}") + 5  # +5 for safety margin

        max_data_per_chunk = self.MAX_DNS_QNAME_LENGTH - base_overhead
        total_chunks = math.ceil(len(data_b36) / max_data_per_chunk)

        chunks = []
        for i in range(total_chunks):
            start = i * max_data_per_chunk
            end = min(start + max_data_per_chunk, len(data_b36))
            chunk_data = data_b36[start:end]

            # Split chunk_data into multiple labels if needed
            data_labels = self._split_data_into_labels(chunk_data, self.MAX_DATA_LABEL_LENGTH)

            # Build query with multiple data labels (m = message)
            data_part = '.'.join(data_labels)
            query = format_dns_query("m", session_id, i, total_chunks, data_part)

            # Validate qname length
            if len(query) > self.MAX_DNS_QNAME_LENGTH:
                # If still too long, reduce data further
                reduced_data_len = self.MAX_DNS_QNAME_LENGTH - len(query) + len(data_part)
                if reduced_data_len > 0:
                    chunk_data = chunk_data[:reduced_data_len]
                    data_labels = self._split_data_into_labels(chunk_data, self.MAX_DATA_LABEL_LENGTH)
                    data_part = '.'.join(data_labels)
                    query = format_dns_query("m", session_id, i, total_chunks, data_part)
                else:
                    raise ValueError(f"Cannot fit data into DNS qname constraints for chunk {i}")

            chunks.append(query)

        return chunks

    def _evict_stale_sessions(self) -> None:
        """Memory Fix M-D1: Evict sessions older than session_ttl to prevent unbounded growth."""
        now = time.time()
        stale = [sid for sid, t in self._session_time.items()
                 if now - t > self._session_ttl]
        for sid in stale:
            self.pending_messages.pop(sid, None)
            self.total_chunks.pop(sid, None)
            self._session_time.pop(sid, None)

    def process_chunk_query(self, query: str) -> Tuple[Optional[str], Optional[bytes]]:
        """
        Process incoming DNS query chunk and return (session_id, complete_message) if ready.
        Returns (session_id, None) if still waiting for more chunks.
        Returns (None, None) if invalid query.

        Expected format: m.sessionid.index.total.data1.data2...dataN.<suffix>
        """
        parts = query.split('.')
        if len(parts) < 6 or parts[0] != 'm' or not validate_dns_suffix_in_query(parts):
            return None, None

        try:
            session_id = parts[1]
            chunk_index = int(parts[2])
            total_chunks = int(parts[3])

            # Memory Fix M-D1: Evict stale sessions on each query
            self._evict_stale_sessions()

            # Extract data labels (everything between total_chunks and suffix)
            suffix_parts = get_dns_suffix_parts()
            data_labels = parts[4:-len(suffix_parts)]  # Skip suffix at end
            chunk_data = ''.join(data_labels)  # Rejoin data parts

            if session_id not in self.pending_messages:
                # Memory Fix M-D3: Reject new sessions when at capacity
                if len(self.pending_messages) >= self._max_pending_sessions:
                    return None, None  # Too many pending sessions — reject
                self.pending_messages[session_id] = {}
                self.total_chunks[session_id] = total_chunks
                self._session_time[session_id] = time.time()
            elif self.total_chunks[session_id] != total_chunks:
                # total_chunks mismatch — reject to prevent DoS
                return None, None

            self.pending_messages[session_id][chunk_index] = chunk_data
            self._session_time[session_id] = time.time()  # Refresh TTL

            # Verify we have ALL expected indices {0, 1, ..., total-1}
            if set(self.pending_messages[session_id].keys()) == set(range(self.total_chunks[session_id])):
                # Memory Fix M-D4: Use list+join instead of string concatenation in loop
                parts_list = [self.pending_messages[session_id][i]
                              for i in range(self.total_chunks[session_id])]
                complete_data = ''.join(parts_list)
                # Evict completed session to prevent memory leak
                del self.pending_messages[session_id]
                del self.total_chunks[session_id]
                self._session_time.pop(session_id, None)

                # Decode using base36
                return session_id, base36_to_bytes(complete_data)

            return session_id, None

        except (ValueError, IndexError, base64.binascii.Error) as e:
            return None, None

    def create_response_chunks(self, encrypted_data: bytes, session_id: str) -> Dict[int, str]:
        """
        Create response chunks as TXT records indexed by chunk number.
        Client will query g.sessionid.index.<suffix> to retrieve chunks.
        """
        # Fernet tokens are already URL-safe base64 bytes, just decode to string for TXT
        # No double-encoding needed - TXT records can handle the Fernet format directly
        data_b64 = encrypted_data.decode('ascii')

        # More conservative sizing to account for index:total: prefix
        max_prefix_size = 10  # "999:999:" with some margin
        max_chunk_size = self.MAX_DNS_RECORD_LENGTH - max_prefix_size

        total_chunks = math.ceil(len(data_b64) / max_chunk_size)
        chunks = {}

        for i in range(total_chunks):
            start = i * max_chunk_size
            end = min(start + max_chunk_size, len(data_b64))
            chunk_data = data_b64[start:end]

            txt_record = f"{i}:{total_chunks}:{chunk_data}"

            # Validate final chunk size
            if len(txt_record) > self.MAX_DNS_RECORD_LENGTH:
                print(f"Warning: Traditional chunk {i} exceeds DNS limit: {len(txt_record)} > {self.MAX_DNS_RECORD_LENGTH}")
                # Reduce chunk data to fit
                max_data_len = self.MAX_DNS_RECORD_LENGTH - len(f"{i}:{total_chunks}:")
                if max_data_len > 0:
                    chunk_data = chunk_data[:max_data_len]
                    txt_record = f"{i}:{total_chunks}:{chunk_data}"
                    print(f"Truncated traditional chunk {i} to {len(txt_record)} bytes")

            chunks[i] = txt_record

        return chunks

    def parse_response_query(self, query: str) -> Tuple[Optional[str], Optional[int]]:
        """
        Parse response retrieval query: g.sessionid.index.<suffix>
        Returns (session_id, chunk_index) or (None, None) if invalid.
        """
        parts = query.split('.')
        suffix_parts = get_dns_suffix_parts()
        expected_length = 3 + len(suffix_parts)  # g + session_id + index + suffix
        if len(parts) != expected_length or parts[0] != 'g' or not validate_dns_suffix_in_query(parts):
            return None, None

        try:
            session_id = parts[1]
            chunk_index = int(parts[2])
            return session_id, chunk_index
        except (ValueError, IndexError):
            return None, None

    def reassemble_response(self, chunks: Dict[int, str]) -> bytes:
        """
        Reassemble response chunks into complete encrypted Fernet token bytes.
        Only returns data if all expected chunks are present.
        """
        if not chunks:
            return b''

        # First, determine the total number of chunks expected
        total_chunks = None
        for chunk_data in chunks.values():
            parts = chunk_data.split(':', 2)
            if len(parts) == 3:
                try:
                    chunk_total = int(parts[1])
                    if total_chunks is None or chunk_total > total_chunks:
                        total_chunks = chunk_total
                except ValueError:
                    continue

        if total_chunks is None:
            return b''  # Can't determine expected chunk count

        # Check if we have all expected chunks (0 to total_chunks-1)
        expected_indices = set(range(total_chunks))
        available_indices = set(chunks.keys())

        if expected_indices != available_indices:
            # Missing chunks - return empty to indicate incomplete data
            # missing = expected_indices - available_indices
            # Silently return empty for incomplete chunks
            return b''

        # All chunks present - reassemble in order
        # Memory Fix M-D4: Use list+join instead of string concatenation in loop
        sorted_chunks = sorted(chunks.items())
        parts_list = []

        for _, chunk in sorted_chunks:
            parts = chunk.split(':', 2)
            if len(parts) == 3:
                parts_list.append(parts[2])

        # Return the Fernet token as bytes (already in proper format)
        complete_data = ''.join(parts_list)
        return complete_data.encode('ascii')

    def create_streaming_chunks(self, crypto_manager, text_segments: list, session_id: str) -> Dict[int, str]:
        """Create streaming chunks with optimal batching for TXT records.

        Args:
            crypto_manager: CryptoManager instance for encryption
            text_segments: List of text pieces to batch and encrypt
            session_id: Session identifier

        Returns:
            Dictionary mapping chunk index to TXT record data
        """
        if not text_segments:
            return {}

        chunks = {}
        # More conservative sizing: account for index:total: prefix (up to "999:999:")
        # Plus significant Fernet overhead (~60-80 bytes for base64 encoding + crypto)
        max_prefix_size = 8  # "999:999:"
        max_fernet_overhead = 80  # More conservative estimate
        max_txt_data_size = self.MAX_DNS_RECORD_LENGTH - max_prefix_size - max_fernet_overhead

        current_batch = ""
        batch_segments = []
        chunk_index = 0

        for segment in text_segments:
            # Try adding this segment to current batch
            test_batch = current_batch + segment

            # Test actual encryption to get real size
            test_encrypted = crypto_manager.encrypt_chunk(test_batch, sequence=0)
            test_b64 = test_encrypted.decode('ascii')
            estimated_final_size = len(f"0:999:{test_b64}")  # Worst case prefix

            if estimated_final_size > self.MAX_DNS_RECORD_LENGTH and current_batch:
                # Current batch is full, create chunk
                encrypted_batch = crypto_manager.encrypt_chunk(current_batch, sequence=chunk_index)
                batch_b64 = encrypted_batch.decode('ascii')

                # Create TXT record (we'll update total count later)
                txt_record = f"{chunk_index}:0:{batch_b64}"
                chunks[chunk_index] = txt_record

                # Start new batch
                current_batch = segment
                batch_segments = [segment]
                chunk_index += 1
            else:
                # Add to current batch
                current_batch = test_batch
                batch_segments.append(segment)

        # Handle final batch
        if current_batch:
            encrypted_batch = crypto_manager.encrypt_chunk(current_batch, sequence=chunk_index)
            batch_b64 = encrypted_batch.decode('ascii')
            txt_record = f"{chunk_index}:0:{batch_b64}"
            chunks[chunk_index] = txt_record
            chunk_index += 1

        # Update all chunks with correct total count and validate size
        total_chunks = len(chunks)
        for idx in chunks:
            parts = chunks[idx].split(':', 2)
            final_chunk = f"{parts[0]}:{total_chunks}:{parts[2]}"

            # Validate final chunk size
            if len(final_chunk) > self.MAX_DNS_RECORD_LENGTH:
                # This shouldn't happen with our sizing, but log it if it does
                print(f"Warning: Chunk {idx} exceeds DNS record limit: {len(final_chunk)} > {self.MAX_DNS_RECORD_LENGTH}")
                # Truncate or split further if needed
                max_data_len = self.MAX_DNS_RECORD_LENGTH - len(f"{parts[0]}:{total_chunks}:")
                if max_data_len > 0:
                    truncated_data = parts[2][:max_data_len]
                    final_chunk = f"{parts[0]}:{total_chunks}:{truncated_data}"
                    print(f"Truncated chunk {idx} to {len(final_chunk)} bytes")

            chunks[idx] = final_chunk

        return chunks

    def reassemble_streaming_chunks(self, crypto_manager, chunks: Dict[int, str]) -> str:
        """Reassemble streaming chunks by decrypting each individually.

        Args:
            crypto_manager: CryptoManager instance for decryption
            chunks: Dictionary mapping chunk index to TXT record data

        Returns:
            Complete reassembled and decrypted text
        """
        if not chunks:
            return ""

        # Sort chunks by index
        sorted_chunks = sorted(chunks.items())
        # Memory Fix M-D4: Use list+join instead of string concatenation
        text_parts = []

        for _, chunk_data in sorted_chunks:
            parts = chunk_data.split(':', 2)
            if len(parts) == 3:
                encrypted_data = parts[2].encode('ascii')
                try:
                    decrypted_segment = crypto_manager.decrypt_chunk(encrypted_data)
                    text_parts.append(decrypted_segment)
                except Exception:
                    # Skip corrupted chunks
                    continue

        return ''.join(text_parts)