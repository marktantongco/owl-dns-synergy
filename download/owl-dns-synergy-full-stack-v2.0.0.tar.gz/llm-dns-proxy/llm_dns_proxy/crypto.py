"""
Encryption utilities using Fernet for secure message transport.
"""

import base64
import os
import threading
import zlib
from cryptography.fernet import Fernet

# ─── Memory Fix M-C1: Global decompression budget (100MB concurrent) ───
_MAX_DECOMPRESS_BUDGET = 100 * 1024 * 1024  # 100 MB total concurrent decompressed output
_current_decompress_bytes = 0
_decompress_lock = threading.Lock()


class CryptoManager:
    def __init__(self, key: bytes = None):
        if key is None:
            key = os.getenv('LLM_PROXY_KEY')
            if key:
                key = key.encode()
            else:
                raise ValueError(
                    "LLM_PROXY_KEY not set — client and server require a shared key. "
                    "Set LLM_PROXY_KEY in .env before starting."
                )

        if isinstance(key, str):
            key = key.encode()

        self.fernet = Fernet(key)

    @classmethod
    def generate_key(cls) -> bytes:
        """Generate a new encryption key."""
        return Fernet.generate_key()

    def encrypt(self, message: str) -> bytes:
        """Encrypt a message with compression and return raw Fernet token bytes."""
        # Compress first for better efficiency
        compressed = zlib.compress(message.encode(), level=9)
        # Fernet.encrypt() returns URL-safe base64 bytes
        encrypted = self.fernet.encrypt(compressed)
        return encrypted

    def decrypt(self, encrypted_data: bytes) -> str:
        """Decrypt and decompress raw Fernet token bytes.

        Memory Fix M-C1: Enforces a global 100MB concurrent decompression budget
        to prevent memory exhaustion from many parallel decrypt calls (e.g., DNS
        flood with encrypted payloads). Raises MemoryError if budget exceeded.
        """
        global _current_decompress_bytes
        # Decrypt the Fernet token
        decrypted = self.fernet.decrypt(encrypted_data, ttl=300)  # Replay protection: reject tokens >5min old
        # Peek at decompressed size without fully decompressing (zlib header)
        # Estimate worst-case decompressed size from compressed input
        estimated_size = len(decrypted) * 12  # zlib typical ratio ~3-12x
        with _decompress_lock:
            if _current_decompress_bytes + estimated_size > _MAX_DECOMPRESS_BUDGET:
                raise MemoryError(
                    f"Decompression budget exceeded: "
                    f"{_current_decompress_bytes}/{_MAX_DECOMPRESS_BUDGET} bytes. "
                    f"Rejecting decrypt to prevent OOM."
                )
            _current_decompress_bytes += estimated_size
        try:
            # Decompress the result with size limit (zip bomb protection)
            decompressed = zlib.decompress(decrypted, bufsize=10*1024*1024)  # max 10MB decompressed
            return decompressed.decode()
        finally:
            with _decompress_lock:
                _current_decompress_bytes -= estimated_size

    def encrypt_chunk(self, text_chunk: str, sequence: int = 0) -> bytes:
        """Encrypt a small text chunk for streaming.

        Args:
            text_chunk: Small piece of text to encrypt
            sequence: Sequence number for ordering (optional metadata)

        Returns:
            Encrypted chunk as Fernet token bytes
        """
        # For streaming, we don't compress individual small chunks as it's inefficient
        # and can actually increase size for small strings
        chunk_data = text_chunk.encode('utf-8')
        return self.fernet.encrypt(chunk_data)

    def decrypt_chunk(self, encrypted_chunk: bytes) -> str:
        """Decrypt a streaming text chunk.

        Args:
            encrypted_chunk: Encrypted chunk bytes

        Returns:
            Decrypted text chunk
        """
        decrypted_data = self.fernet.decrypt(encrypted_chunk, ttl=300)  # Replay protection
        return decrypted_data.decode('utf-8')
